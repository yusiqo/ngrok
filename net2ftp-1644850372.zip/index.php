<?php
define("SCRIPT_ROOT", dirname(__FILE__)); // number of allowed page requests for the user define("CONTROL_MAX_REQUESTS", 3); // time interval to start counting page requests (seconds) define("CONTROL_REQ_TIMEOUT", 2); // seconds to punish the user who has exceeded in doing requests define("CONTROL_BAN_TIME", 5); // writable directory to keep script data define("SCRIPT_TMP_DIR", SCRIPT_ROOT."/flood"); // you don't need to edit below this line define("USER_IP", $_SERVER["REMOTE_ADDR"]); define("CONTROL_DB", SCRIPT_TMP_DIR."/ctrl"); define("CONTROL_LOCK_DIR", SCRIPT_TMP_DIR."/lock"); define("CONTROL_LOCK_FILE", CONTROL_LOCK_DIR."/".md5(USER_IP)); @mkdir(CONTROL_LOCK_DIR); @mkdir(SCRIPT_TMP_DIR); if (file_exists(CONTROL_LOCK_FILE)) { if (time()-filemtime(CONTROL_LOCK_FILE) > CONTROL_BAN_TIME) { // this user has complete his punishment unlink(CONTROL_LOCK_FILE); } else { // too many requests echo "<h1>DENIED</h1>"; echo "Please try later."; touch(CONTROL_LOCK_FILE); die; } } function antiflood_countaccess() { // counting requests and last access time $control = Array(); if (file_exists(CONTROL_DB)) { $fh = fopen(CONTROL_DB, "r"); $control = array_merge($control, unserialize(fread($fh, filesize(CONTROL_DB)))); fclose($fh); } if (isset($control[USER_IP])) { if (time()-$control[USER_IP]["t"] < CONTROL_REQ_TIMEOUT) { $control[USER_IP]["c"]++; } else { $control[USER_IP]["c"] = 1; } } else { $control[USER_IP]["c"] = 1; } $control[USER_IP]["t"] = time(); if ($control[USER_IP]["c"] >= CONTROL_MAX_REQUESTS) { // this user did too many requests within a very short period of time $fh = fopen(CONTROL_LOCK_FILE, "w"); fwrite($fh, USER_IP); fclose($fh); } // writing updated control table $fh = fopen(CONTROL_DB, "w"); fwrite($fh, serialize($control)); fclose($fh); }

$limitps = 10;
if (!isset($_SESSION['first_request'])){
    $_SESSION['requests'] = 0;
    $_SESSION['first_request'] = $_SERVER['REQUEST_TIME'];
}
$_SESSION['requests']++;
if ($_SESSION['requests']>=10 && strtotime($_SERVER['REQUEST_TIME'])-strtotime($_SESSION['first_request'])<=1){
    //write the IP to a banned_ips.log file and configure your server to retrieve the banned ips from there - now you will be handling this IP outside of PHP
    $_SESSION['banip']==1;
}elseif(strtotime($_SERVER['REQUEST_TIME'])-strtotime($_SESSION['first_request']) > 2){
    $_SESSION['requests'] = 0;
    $_SESSION['first_request'] = $_SERVER['REQUEST_TIME'];
}

if ($_SESSION['banip']==1) {
    header('HTTP/1.1 503 Service Unavailable');
    die;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="Sync is a landing page HTML template built with Bootstrap 4 for presenting mobile apps to the online audience and for getting visitors to become users.">
    <meta name="author" content="Inovatik">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on LinkedIn, Facebook, Google+ -->
	<meta property="og:site_name" content="" /> <!-- website name -->
	<meta property="og:site" content="" /> <!-- website link -->
	<meta property="og:title" content=""/> <!-- title shown in the actual shared post -->
	<meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
	<meta property="og:image" content="" /> <!-- image link, make sure it's jpg -->
	<meta property="og:url" content="" /> <!-- where do you want your post to link to -->
	<meta property="og:type" content="article" />

    <!-- Webpage Title -->
    <title>DeltaMedya - En İyi Hesap Checker Sitesi</title>
    
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,700&display=swap&subset=latin-ext" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/swiper.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!-- Favicon  -->
    <link rel="icon" href="images/favicon.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">
    
    <!-- Preloader -->
	<div class="spinner-wrapper">
        <div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>
    </div>
    <!-- end of preloader -->
    

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
        <div class="container">
            <!-- Text Logo - Use this if you don't have a graphic logo -->
            <!-- <a class="navbar-brand logo-text page-scroll" href="index.html">Sync</a> -->

            <!-- Image Logo -->
            <a class="navbar-brand logo-image" href="index.html"><img src="https://i.hizliresim.com/mv824k4.png" alt="alternative"></a> 
            
            <!-- Mobile Menu Toggle Button -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-awesome fas fa-bars"></span>
                <span class="navbar-toggler-awesome fas fa-times"></span>
            </button>
<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegramim.ru/widget-button/index.php?id=@portakalmedya";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<a href="https://t.me/portakalmedya" target="_blank" class="telegramim_button telegramim_shadow telegramim_pulse" style="font-size:26px;width:48px;background:#27A5E7;box-shadow:1px 1px 5px #27A5E7;color:#FFFFFF;border-radius:50px;" title=""><i></i></a>

            <!-- end of mobile menu toggle button -->

            <div class="collapse navbar-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="https://deltamedya.tk/exxen">Exxen Checker</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="https://deltamedya.tk/blutv">BluTv Checker</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="https://deltamedya.tk/trendyol">TrendYol Checker</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="https://deltamedya.tk/smsonay"SmsOnay Checker</a>
                    </li>

                    <!-- Dropdown Menu -->          
                    <li class="nav-item dropdown">
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="https://deltamedya.tk/exxen"><span class="item-text">Exxen Checker</span></a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="https://deltamedya.tk/blutv"><span class="item-text">BluTv Checker</span></a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="https://deltamedya.tk/trendyol"><span class="item-text">TrendYol Checker</span></a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="https://deltamedya.tk/smsonay"><span class="item-text">SmsOnay Checker</span></a>
                        </div>
                    </li>
                    <!-- end of dropdown menu -->
                </ul>
                </span>
            </div>
        </div> <!-- end of container -->
    </nav> <!-- end of navbar -->
    <!-- end of navigation -->


    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-container">
                        <h1>Online Checker Sitesi</h1>
                        <p class="p-large p-heading">İstediğin Hesap Türünü Seç Komboyu Yapıştır Check Etmeye Başla</p>
                        <a class="btn-solid-lg" href="https://deltamedya.tk/exxen"><i class="fab fa-google-play"></i>Exxen</a>
                        <a class="btn-solid-lg" href="https://deltamedya.tk/blutv"><i class="fab fa-google-play"></i>BluTv</a>
                        <a class="btn-solid-lg" href="https://deltamedya.tk/trendyol"><i class="fab fa-google-play"></i>Trendyol</a>
                        <a class="btn-solid-lg" href="https://deltamedya.tk/smsonay"><i class="fab fa-google-play"></i>SmsOnay</a>
                    </div> <!-- end of text-container -->
                </div> <!-- end of col -->
            </div> <!-- end of row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="image-container">
                       <img class="img-fluid" src="images/header-iphone.png" alt="alternative">
                    </div> <!-- end of text-container -->
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
        <div class="deco-white-circle-1">
            <img src="images/decorative-white-circle.svg" alt="alternative">
        </div> <!-- end of deco-white-circle-1 -->
        <div class="deco-white-circle-2">
            <img src="images/decorative-white-circle.svg" alt="alternative">
        </div> <!-- end of deco-white-circle-2 -->
        <div class="deco-blue-circle">
            <img src="images/decorative-blue-circle.svg" alt="alternative">
        </div> <!-- end of deco-blue-circle -->
        <div class="deco-yellow-circle">
            <img src="images/decorative-yellow-circle.svg" alt="alternative">
        </div> <!-- end of deco-yellow-circle -->
        <div class="deco-green-diamond">
            <img src="images/decorative-green-diamond.svg" alt="alternative">
        </div> <!-- end of deco-yellow-circle -->
    </header> <!-- end of header -->
    <!-- end of header -->


    <!-- Small Features -->
    <div class="cards-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    
                  
    <!-- Copyright -->
    <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="p-small">Copyright © 2020 <a href="https://deltamedya.tk">DeltaMedya</a> - All rights reserved</p>
                </div> <!-- end of col -->
            </div> <!-- enf of row -->
        </div> <!-- end of container -->
    </div> <!-- end of copyright --> 
    <!-- end of copyright -->
    
    	
    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>